from __future__ import annotations
from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4
from pydantic import BaseModel, Field


class MemoryType(str, Enum):
    strategic = "strategic"
    project = "project"
    conversation = "conversation"
    document = "document"
    personal = "personal"
    relationship = "relationship"
    knowledge_link = "knowledge_link"
    system = "system"


class MemoryWriteRequest(BaseModel):
    memory_id: UUID = Field(default_factory=uuid4)
    memory_type: MemoryType
    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    source_agent: str
    task_id: UUID | None = None
    project_id: str | None = None
    tags: list[str] = Field(default_factory=list)
    ttl_hours: int | None = None


class MemoryQuery(BaseModel):
    query_text: str
    memory_types: list[MemoryType] = Field(default_factory=list)
    requesting_agent: str
    task_id: UUID | None = None
    project_id: str | None = None
    top_k: int = Field(default=12, ge=1, le=50)
    recency_days: int | None = None


class MemoryQueryResult(BaseModel):
    query_id: UUID = Field(default_factory=uuid4)
    results: list[dict[str, Any]] = Field(default_factory=list)
    total_found: int = 0
    retrieval_ms: float = 0.0
