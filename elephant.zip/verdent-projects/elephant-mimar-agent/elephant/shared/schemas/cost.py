from __future__ import annotations
from datetime import datetime
from uuid import UUID, uuid4
from pydantic import BaseModel, Field


class CostRecord(BaseModel):
    record_id: UUID = Field(default_factory=uuid4)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    agent_name: str
    task_id: UUID | None = None
    model_id: str
    provider: str
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float
    cumulative_today_usd: float = 0.0


class BudgetStatus(BaseModel):
    daily_limit_usd: float
    spent_today_usd: float
    percent_used: float
    alert_level: str
    cloud_calls_active: bool
    last_updated: datetime
