from __future__ import annotations
from datetime import datetime
from enum import Enum
from uuid import UUID
from pydantic import BaseModel, Field


class AgentName(str, Enum):
    planner = "planner"
    researcher = "researcher"
    creator = "creator"
    visual = "visual"
    critic = "critic"
    memory_agent = "memory_agent"
    executor = "executor"
    watchdog = "watchdog"
    auditor = "auditor"
    interacter = "interacter"
    reporter = "reporter"


class AgentHealthStatus(str, Enum):
    healthy = "healthy"
    degraded = "degraded"
    unresponsive = "unresponsive"
    offline = "offline"


class AgentHeartbeat(BaseModel):
    agent_name: AgentName
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    status: AgentHealthStatus = AgentHealthStatus.healthy
    current_task_id: UUID | None = None
    tasks_completed_today: int = 0
    cost_today_usd: float = 0.0
    error_message: str | None = None


class AgentStatusRead(BaseModel):
    agent_name: AgentName
    status: AgentHealthStatus
    last_heartbeat: datetime | None
    current_task_id: UUID | None
    tasks_completed_today: int
    cost_today_usd: float
    uptime_seconds: float | None
    enabled: bool = True

    class Config:
        from_attributes = True
