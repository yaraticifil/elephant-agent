from __future__ import annotations


class ElephantError(Exception):
    pass


class TaskNotFoundError(ElephantError):
    def __init__(self, task_id: str):
        super().__init__(f"Task not found: {task_id}")


class AgentNotFoundError(ElephantError):
    def __init__(self, agent_name: str):
        super().__init__(f"Agent not found: {agent_name}")


class BusNotConnectedError(ElephantError):
    def __init__(self):
        super().__init__("Message bus is not connected")


class ApprovalRequiredError(ElephantError):
    def __init__(self, task_id: str):
        super().__init__(f"Approval required for task: {task_id}")


class BudgetExceededError(ElephantError):
    def __init__(self):
        super().__init__("Daily budget exceeded — cloud calls suspended")
