# ELEPHANT — README

## Kurulum

### 1. env dosyasını oluştur
```
copy env.template .env
```
`.env` dosyasındaki şifreleri değiştir.

### 2. Docker ile başlat
```
cd deploy/docker
docker-compose up -d
```

### 3. Sağlık kontrolü
```
python scripts/health_check.py
```

### 4. Veritabanını başlat (ilk kurulumda)
```
python scripts/init_db.py
```

## Servisler

| Servis | Port | Açıklama |
|---|---|---|
| Orchestrator | 8000 | Ana API |
| Dashboard Backend | 8001 | Dashboard proxy API |
| Interacter | 8010 | Görev oluşturma girişi |
| PostgreSQL | 5432 | Veritabanı |
| Redis | 6379 | Message bus |
| Qdrant | 6333 | Vector store |
| Neo4j | 7474/7687 | Knowledge graph |

## Örnek görev oluşturma

```bash
curl -X POST http://localhost:8010/input \
  -H "Content-Type: application/json" \
  -d '{"title": "AI stratejisi araştır", "task_type": "research", "mode": "work"}'
```

```bash
curl http://localhost:8000/tasks
curl http://localhost:8000/agents
```
