"""
init_db.py - Run once to initialize the database.
Usage: python scripts/init_db.py
"""
import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from services.memory.relational.models import Base, AgentRegistry
from shared.config.base import get_settings

settings = get_settings()

ALL_AGENTS = [
    "planner", "researcher", "creator", "visual", "critic",
    "memory_agent", "executor", "watchdog", "auditor", "interacter", "reporter"
]


async def init():
    print(f"Connecting to: {settings.POSTGRES_URL}")
    engine = create_async_engine(settings.POSTGRES_URL, echo=True)
    session_factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("Tables created.")

    async with session_factory() as session:
        for name in ALL_AGENTS:
            existing = await session.get(AgentRegistry, name)
            if not existing:
                session.add(AgentRegistry(agent_name=name, status="offline"))
                print(f"Registered agent: {name}")
            else:
                print(f"Agent already exists: {name}")
        await session.commit()

    print("Database initialized successfully.")
    await engine.dispose()


if __name__ == "__main__":
    asyncio.run(init())
