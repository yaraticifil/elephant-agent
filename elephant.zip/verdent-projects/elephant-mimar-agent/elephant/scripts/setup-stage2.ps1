# ELEPHANT Stage 2 — Setup Script
# Copies all Python services into the running elephant project and rebuilds Docker
# Run from PowerShell: .\scripts\setup-stage2.ps1

$SRC = "C:\Users\Lenovo\.verdent\verdent-projects\elephant-mimar-agent\elephant"
$DST = "C:\Users\Lenovo\.verdent\elephant"

Write-Host "=== ELEPHANT Stage 2 Setup ===" -ForegroundColor Cyan
Write-Host "Source: $SRC" -ForegroundColor Gray
Write-Host "Dest:   $DST" -ForegroundColor Gray

# ── 1. Stop running containers ─────────────────────────────────────────────
Write-Host "`n[1/5] Stopping existing containers..." -ForegroundColor Yellow
Set-Location $DST
docker compose down 2>$null

# ── 2. Create directory structure in elephant project ─────────────────────
Write-Host "`n[2/5] Creating directory structure..." -ForegroundColor Yellow

$dirs = @(
    "shared\schemas",
    "shared\messaging",
    "shared\config",
    "shared\logging",
    "services\orchestrator",
    "services\agents\base",
    "services\agents\planner",
    "services\agents\researcher",
    "services\agents\creator",
    "services\agents\critic",
    "services\agents\auditor",
    "services\agents\executor",
    "services\agents\reporter",
    "services\agents\memory_agent",
    "services\agents\visual",
    "services\agents\watchdog",
    "services\agents\interacter",
    "services\memory\vector",
    "services\memory\graph",
    "services\memory\retrieval"
)
foreach ($d in $dirs) {
    New-Item -ItemType Directory -Force -Path "$DST\$d" | Out-Null
}

# ── 3. Copy Python source files ────────────────────────────────────────────
Write-Host "`n[3/5] Copying Python source files..." -ForegroundColor Yellow

$fileMappings = @(
    # Shared
    @{ s = "shared\schemas\task.py";              d = "shared\schemas\task.py" },
    @{ s = "shared\schemas\message.py";           d = "shared\schemas\message.py" },
    @{ s = "shared\messaging\bus.py";             d = "shared\messaging\bus.py" },
    @{ s = "shared\messaging\events.py";          d = "shared\messaging\events.py" },
    @{ s = "shared\config\base.py";               d = "shared\config\base.py" },
    @{ s = "shared\logging\config.py";            d = "shared\logging\config.py" },
    # Orchestrator
    @{ s = "services\orchestrator\main_v2.py";    d = "services\orchestrator\main.py" },
    # Base agent
    @{ s = "services\agents\base\agent.py";       d = "services\agents\base\agent.py" },
    # Agents
    @{ s = "services\agents\planner\agent.py";    d = "services\agents\planner\agent.py" },
    @{ s = "services\agents\researcher\agent.py"; d = "services\agents\researcher\agent.py" },
    @{ s = "services\agents\creator\agent.py";    d = "services\agents\creator\agent.py" },
    @{ s = "services\agents\critic\agent.py";     d = "services\agents\critic\agent.py" },
    @{ s = "services\agents\auditor\agent.py";    d = "services\agents\auditor\agent.py" },
    @{ s = "services\agents\executor\agent.py";   d = "services\agents\executor\agent.py" },
    @{ s = "services\agents\reporter\agent.py";   d = "services\agents\reporter\agent.py" },
    @{ s = "services\agents\memory_agent\agent.py"; d = "services\agents\memory_agent\agent.py" },
    @{ s = "services\agents\visual\agent.py";     d = "services\agents\visual\agent.py" },
    @{ s = "services\agents\watchdog\agent.py";   d = "services\agents\watchdog\agent.py" },
    @{ s = "services\agents\interacter\agent.py"; d = "services\agents\interacter\agent.py" },
    # Memory clients
    @{ s = "services\memory\vector\qdrant_client.py"; d = "services\memory\vector\qdrant_client.py" },
    @{ s = "services\memory\graph\neo4j_client.py";   d = "services\memory\graph\neo4j_client.py" },
    @{ s = "services\memory\retrieval\pipeline.py";   d = "services\memory\retrieval\pipeline.py" }
)

foreach ($m in $fileMappings) {
    $src_file = "$SRC\$($m.s)"
    $dst_file = "$DST\$($m.d)"
    if (Test-Path $src_file) {
        Copy-Item -Path $src_file -Destination $dst_file -Force
        Write-Host "  COPIED: $($m.d)" -ForegroundColor Green
    } else {
        Write-Host "  MISSING: $src_file" -ForegroundColor Red
    }
}

# ── 4. Create __init__.py files ────────────────────────────────────────────
Write-Host "`n[4/5] Creating __init__.py files..." -ForegroundColor Yellow
$initDirs = @(
    "shared", "shared\schemas", "shared\messaging", "shared\config", "shared\logging",
    "services", "services\orchestrator",
    "services\agents", "services\agents\base",
    "services\agents\planner", "services\agents\researcher", "services\agents\creator",
    "services\agents\critic", "services\agents\auditor", "services\agents\executor",
    "services\agents\reporter", "services\agents\memory_agent", "services\agents\visual",
    "services\agents\watchdog", "services\agents\interacter",
    "services\memory", "services\memory\vector", "services\memory\graph", "services\memory\retrieval"
)
foreach ($d in $initDirs) {
    $initFile = "$DST\$d\__init__.py"
    if (-not (Test-Path $initFile)) {
        "" | Out-File -FilePath $initFile -Encoding utf8
    }
}

# ── 5. Copy Dockerfile and docker-compose ─────────────────────────────────
Write-Host "`n[5/5] Installing Dockerfile and docker-compose..." -ForegroundColor Yellow
Copy-Item -Path "$SRC\Dockerfile" -Destination "$DST\Dockerfile" -Force
Copy-Item -Path "$SRC\deploy\docker\docker-compose.yml" -Destination "$DST\docker-compose.yml" -Force
Write-Host "  COPIED: Dockerfile" -ForegroundColor Green
Write-Host "  COPIED: docker-compose.yml" -ForegroundColor Green

# ── Done ───────────────────────────────────────────────────────────────────
Write-Host "`n=== Setup complete! ===" -ForegroundColor Cyan
Write-Host "Now run: cd $DST && docker compose up -d --build" -ForegroundColor Yellow
