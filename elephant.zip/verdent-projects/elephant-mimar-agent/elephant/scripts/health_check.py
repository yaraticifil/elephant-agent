"""
health_check.py - Verify all services are healthy.
Usage: python scripts/health_check.py
Exit 0 = all healthy, Exit 1 = something is down.
"""
import asyncio
import sys
import os
import httpx

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

CHECKS = [
    ("Orchestrator", "http://localhost:8000/health"),
    ("Dashboard Backend", "http://localhost:8001/health"),
    ("Interacter", "http://localhost:8010/health"),
]


async def check():
    all_ok = True
    async with httpx.AsyncClient(timeout=5) as client:
        for name, url in CHECKS:
            try:
                resp = await client.get(url)
                if resp.status_code == 200:
                    print(f"[OK]   {name}: {url}")
                else:
                    print(f"[FAIL] {name}: HTTP {resp.status_code}")
                    all_ok = False
            except Exception as e:
                print(f"[DOWN] {name}: {e}")
                all_ok = False

    print()
    if all_ok:
        print("All services healthy.")
    else:
        print("Some services are DOWN.")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(check())
