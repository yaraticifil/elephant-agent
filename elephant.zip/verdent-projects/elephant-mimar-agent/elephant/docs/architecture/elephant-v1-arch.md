ELEPHANT — Chief Architect Design Document Version 1.0 | Author: Chief Architect Agent | For: Salim Gümüş / Creative Elephant
EXECUTIVE SUMMARY
ELEPHANT is a multi-agent, memory-driven, cloud-local hybrid AI operating system. It is not a product wrapper around a language model. It is a structured system of specialized agents, a persistent multi-typed memory architecture, a governed tool layer, a model router, and a supervision interface — all operating as a coherent whole. Its purpose is dual: serve professional work (research, strategy, content, execution) and support personal life (reminders, communication, decisions, organization) — under a single unified architecture with strict mode separation.
ELEPHANT is designed to be implemented in stages, with v1 being a fully functional single-user system and v2 opening the path toward a team or commercial platform. This document is the founding design contract. It defines what gets built, in what order, with what constraints, by which builder agents. Nothing in this document is aspirational speculation — every element is an engineering decision with justifiable trade-offs.
Non-negotiable design axioms:
No consequential real-world action without an approval token
No personal data ever leaves the local machine
No agent operates without logging
No cost runs unchecked
No memory type mixes with another type's storage backend

[See full document in project requirements for detailed architecture, layer rules, agent specifications, task flow, memory design, tools, model routing, and implementation roadmap.]
