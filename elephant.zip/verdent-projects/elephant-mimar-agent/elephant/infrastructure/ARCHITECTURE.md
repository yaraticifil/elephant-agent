# ELEPHANT: Hibrit Yapay Zekâ İşletim Sistemi Mimari Dokümanı

## 1. Başlık ve Amaç

Bu doküman, ELEPHANT (Multi-Agent AI Operating System) için yerel ve bulut (hibrit) altyapı mimarisinin standartlarını ve tasarım kararlarını tanımlar. 

**ELEPHANT Altyapı Mimarisinin Maksadı:** Sadece bir dil modeli barındıran basit bir sohbet uygulaması değil; kendi kendine plan yapan, araştıran, üreten, denetleyen ve icra eden otonom bir "dijital şirket" kurmaktır. 

**Neden Hibrit Yapı:** İşletim sisteminin bilişsel çekirdeği (veri tabanları, vektör hafıza, kritik orkestrasyon) tamamen yerel cihazda (Local Core) tutularak gizlilik ve kalıcılık garanti altına alınır. Ancak yoğun analiz, geniş çaplı araştırma ve görsel üretim gibi aşırı donanım gücü isteyen işlemler buluta (Cloud Layer) devredilir. Bu strateji, bir GTX 1650 ve 16 GB RAM gibi son kullanıcı donanımlarında bile devasa zekâ kapasitelerinin darboğaz yaşanmadan kullanılabilmesini sağlar.

---

## 2. Genel Sistem Haritası

Sistem, belirli görevleri üstlenen konteyner tabanlı servislerin uyum içinde çalışmasıyla var olur.

| Servis Adı | Görev | Katman (Local/Cloud/Hybrid) |
| --- | --- | --- |
| **PostgreSQL** | Structured Memory (Görevler, Raporlar, Loglar) | Local |
| **Redis** | Message Bus ve Hızlı Ön Bellek (RabbitMQ alternatifi) | Local |
| **Qdrant** | Semantic Memory (Vektörel anlamsal hatırlama) | Local |
| **Neo4j** | Relationship Memory (Bilgi grafiği ve entiteler arası ilişkiler) | Local |
| **Ollama** | Yerel Dil Modeli Çıkarımı (Örn. Mistral) | Local (Opsiyonel) |
| **Orchestrator** | Task Engine (Sistem scheduler'ı ve ana API Geçidi) | Local |
| **Gateway** | Dış dünya ile iletişim, API endpointleri | Local |
| **Jules Interface**| İnsan Arayüzü (Kullanıcı etkileşimi) | Local |
| **Planner Agent** | Strateji Ekibi (Görevleri alt parçalara böler) | Hybrid |
| **Researcher Agent**| Analistler (Veri toplama, trend analizi) | Hybrid |
| **Creator Agent** | Kreatif Ekip (İçerik, rapor taslakları üretimi) | Hybrid |
| **Critic Agent** | QA (Ton, marka uyumu, kalite denetimi) | Hybrid |
| **Executor Agent** | Operasyon (Sonuç ulaştırma, yayınlama) | Hybrid |
| **Watchdog Agent** | İç Denetim & Güvenlik (Maliyet kontrolü, sistem sağlığı) | Local |
| **Scheduler Agent** | Zamanlanmış Görev Yönetimi | Local |
| **Cloud LLM (API)**| Gelişmiş dil, veri ve görsel işleme servisi | Cloud |

---

## 3. Çekirdek Mimari İlkeleri

ELEPHANT'ın varoluşu üç temel omurgaya dayanır:

1. **Task Engine:** Sistemin işlemcisi. Orchestrator tarafından yönetilen bu birim, verilen ana hedefi (Örn: "Fintech trend research") alt işlere böler (trend bul, rakip analiz et, raporla) ve ajanlara atar.
2. **Memory System:** Sistemin bilinci. 3 katmandan oluşur; PostgreSQL kesin verileri, Qdrant bağlamsal ve anlamsal benzerlikleri, Neo4j ise veriler arası ilişkileri ("Figopara" -> "Faktoring") ağ mimarisiyle saklar.
3. **Message Bus:** Sistemin sinir ağı. Ajanlar arası asenkron iletişim Redis Streams üzerinden sağlanır. Planner'ın Researcher'a verdiği emirler veya Creator'ın ürettiği taslaklar bu hat üzerinden akar.

---

## 4. Ağ Topolojisi

Tüm altyapı Docker üzerinden standartlaştırılmıştır.
* **Ağ Yaklaşımı:** `elephant-network` adında özel bir köprü (bridge) ağı kuruludur.
* **Topoloji Ayrımı:** Veri tabanları (PostgreSQL, Qdrant, Neo4j, Redis) dış dünyaya kesinlikle kapalıdır; host portları sadece `localhost` seviyesinde bağ veya güvenlik duvarı arkasında yönetilir. Yalnızca **Gateway / Orchestrator / Jules** gibi arayüzler dış trafiğe veya spesifik portlara açılır. 

---

## 5. Kalıcılık ve Volume Stratejisi

Konteynerlerin doğası gereği geçici (ephemeral) olan verileri kalıcılaştırmak için Docker named volumes kullanılır:
* `postgres_data`: Yapısal sistem verileri ve loglar.
* `qdrant_data`: Vektörel embedding verileri.
* `neo4j_data`: Bilgi grafiği düğümleri ve kenarları.
* `ollama_models`: İndirilmiş LLM ağırlıkları.
* `logs`: Tüm ajanların ve Orchestrator'ın kalıcı log dosyaları.
* `reports_output` (Host'a bind mount): Executor tarafından üretilen analiz ve pazar raporlarının fiziki çıktısı.
* `agent_workspace`: Ajanların geçici dosya paylaşımları.

---

## 6. Boot Sırası (Başlatma Hiyerarşisi)

Sistem bir şirket gibi departman departman ayağa kalkar:
1. **Veri Katmanı:** Öncelikle Postgres ve Redis başlatılır (`depends_on: service_healthy`).
2. **Hafıza Katmanı:** Qdrant ve Neo4j devreye girer.
3. **Model Katmanı:** (Kullanılıyorsa) Ollama servisi başlar.
4. **Orkestrasyon Katmanı:** Orchestrator ve Gateway başlar, veri tabanı bağlantılarını doğrular.
5. **Ajan Katmanı:** Planner, Researcher, Creator, Critic, Executor, Watchdog ve Scheduler bağımsız süreçler olarak `elephant-network` ağına dâhil olup RabbitMQ/Redis kuyruklarını dinlemeye başlar.
6. **Arayüz:** Jules GUI aktifleşir.

---

## 7. Local vs Cloud Routing Mantığı

Sahip olunan donanım kısıtlı olduğunda sistemin zekice karar alması gerekir:
* **Lokalde Kalan İşler:** Gizliliği ("Sensitive Mode: true") yüksek olan mali veriler, iç yazışmalar, şirket içi stratejiler, hafıza indeksleme (embedding) ve basit denetim (Critic) görevleri Ollama üzerinden veya salt kod tabanlı Python algoritmalarıyla lokalde çözülür.
* **Buluta Devredilen İçerikler:** Devasa web taraması gerektiren trend pazar analizi, karmaşık ve çok adımlı muhakeme (GPT-4 / Claude seviyesinde analiz), ağır görsel üretim gibi süreçler ilgili Cloud API'lerine devredilir.
* **Neden:** Çünkü hassas veri dışarı çıkamaz; ancak genel pazar verisini analiz etmek için GTX 1650'yi günlerce meşgul etmenin bir anlamı yoktur.

---

## 8. Task Engine Şeması ve Görev Yaşam Döngüsü

**Görev Şeması (Task Schema):**
* `task_id`: UUID
* `parent_task_id`: Alt görevler için ana hedefin ID'si
* `title`: "Fintech pazarında yeni faktoring girişimleri"
* `description`: Detaylı brief.
* `status`: queued -> in_progress -> review -> completed / failed
* `priority`: critical / high / standard / low
* `assigned_agent`: "researcher"
* `created_at` / `updated_at`: Timestamp
* `result_location`: Çıktının yazılacağı disk / hafıza adresi
* `retry_count`: Hata durumunda yeniden deneme sınırı
* `visibility`: "private" / "team"
* `sensitivity_level`: "high" / "low"

**Görev Yaşam Döngüsü:**
Kullanıcı hedefini verir (Oluşturma) -> Planner hedefi alt tasklara böler (Planlama) -> Researcher internetten veri çeker (Araştırma) -> Creator taslağı yazar (Üretim) -> Critic tonu denetler (Eleştiri) -> Executor repoyu/raporu hazırlar (İcra) -> Qdrant/Neo4j'ye özet arşivlenir (Hafızaya Yazım).

---

## 9. Hafıza Mimarisi

* **PostgreSQL (Structured):** "Kim ne zaman hangi görevi bitirdi? Görevin JSON payload'u nedir?"gibi klasik metadata takibi yapar.
* **Qdrant (Semantic):** Geçmiş pazar araştırmalarını kelime kökünden bağımsız "anlam" olarak arar (Örn: "Nakdi krediye benzeyen modeller nelerdi?" sorusu ile eski faktoring kayıtlarını bulur).
* **Neo4j (Relationship):** Grafik düşünür. Şirketlerin, ürünlerin, rakiplerin kesişim kümelerini izler (Entity -> RELATES_TO -> Entity).
* Bunların tamamı Orchestrator'daki `Memory System` modülü eşgüdümünde RAG (Retrieval-Augmented Generation) hattını besler.

---

## 10. Kaynak Stratejisi (GTX 1650 / 16 GB RAM)

**Optimizasyon Stratejisi:** Sistemin tamamını aynı anda zorlamak bu donanımda çöküş yaratır.
* **Sürekli Açık Kalması Gerekenler:** Orchestrator, PostgreSQL, Redis, Watchdog. (Çok az RAM tüketirler).
* **Gerektiğinde Açılması Gerekenler:** Ollama konteyneri lokal çıkarım gerektiğinde tetiklenmeli, edilgen durumlarda RAM iadesi yapmalıdır. (Veya 4-bit kuantize Mistral/Llama3 (max 4.5 GB RAM) limitiyle çalıştırılmalıdır).
* **Bulut Ne Zaman Zorunlu:** Eş zamanlı >2 ajan aktivitesi varsa, 16 GB RAM limitini aşmamak için Creator ve Researcher dış API'lere devredilir.
* **GPU Dikkatleri:** VRAM (4 GB) kısıtlıdır. Sadece embedding modeli veya tek bir minyatür LLM GPU'ya yüklenecektir.

---

## 11. Fintech İş Akışları Ortak Öyküsü

Bir "Faktoring Pazar Analizi" akışı:
1. **Trend Taraması:** Researcher interneti tarar ve güncel B2B BNPL / KOBİ faktoring modellerini çıkarır.
2. **Rakip İstihbaratı:** Qdrant'taki geçmiş neo-faktoring firmaları ile Neo4j'deki "Figopara" ve "Tam Finans" düğümleri çekilir.
3. **Ürün Fikri Üretimi:** Creator, çekilen dış verilerle şirket içi know-how'ı harmanlayarak "Finansın Expedia'sı" konseptine uygun, KOBİ kredisiyle entegre bir tahsilat otomasyonu stratejisi kurgular.
4. **Stratejik Not / Rapor Üretimi:** Executor, Critic onayından geçen dokümanı şablonlayıp `reports` klasörüne yazar ve kullanıcıyı bilgilendirir.

---

## 12. Güvenlik ve Sır Yönetimi

* `secrets` (API kodları) asla `docker-compose.local.yml` veya git repolarına yazılmaz; doğrudan okunan `.env` dosyasında yapılandırılır.
* Hiçbir veritabanı dış ağlardan erişilebilir olmamalıdır (`elephant-network` içi izolasyon).
* API'ye gönderilen verilerde *Minimum Payload İlkesi* geçerlidir; şahsa sıkı sıkıya bağlı kurumsal dokümanlar API’ye gönderilmeden lokal PII maskelemesinden geçirilmelidir.
* **Watchdog**, tüm cloud API çağrılarını kontrol eder; günlük belirlenen USD bütçesi (Örn: `$10.0`) aşıldığında sistemi katı dondurma moduna alır.

---

## 13. Gözlemlenebilirlik ve Log Yaklaşımı

* Ajanların servis logları asenkron olarak ortak bir "log ingestion" panosuna akmalıdır.
* Watchdog, rutin olarak sistem sağlığını ve bekleyen (stale) görevleri denetler.
* Hata izleme (Exception Tracking) mekanizması ile Planner ve Worker çökmeleri izolasyon ortamında yeniden başlatılabilir (`retry_count`).
* Kullanıcıya günlük olarak "Tamamlanan İşler" özet raporu sunulur.

---

## 14. Sonuç

**ELEPHANT bir chatbot değildir.** 
* **Local Core** = Sistem varlığının güvencesi ve kurumsal bilişsel çekirdek.
* **Cloud Layer** = Zorlandığında ulaşılan genişletilmiş beyin kapasitesi.
* **Jules** = Operasyonel yönetimi kolaylaştıran minimal insan arayüzü.

Sonuç itibarıyla ELEPHANT, tıpkı disiplinli bir holding bünyesindeki kurmay zekâ gibi insansız çalışan ve geceleri dâhi kendi gündeminde ilerleyen kişisel yapay zekâ işletim sisteminizdir.
