from __future__ import annotations
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import httpx
from shared.logging.config import configure_logging
from shared.config.base import get_settings

settings = get_settings()
configure_logging("dashboard_backend", settings.LOG_LEVEL)
logger = logging.getLogger(__name__)

app = FastAPI(title="ELEPHANT Dashboard API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/health")
async def health():
    return {"service": "dashboard_backend", "status": "ok"}


@app.get("/api/tasks")
async def proxy_tasks(status: str = None, mode: str = None, limit: int = 50):
    params = {}
    if status:
        params["status"] = status
    if mode:
        params["mode"] = mode
    params["limit"] = limit
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(f"{settings.ORCHESTRATOR_URL}/tasks", params=params)
        resp.raise_for_status()
        return resp.json()


@app.get("/api/agents")
async def proxy_agents():
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(f"{settings.ORCHESTRATOR_URL}/agents")
        resp.raise_for_status()
        return resp.json()
