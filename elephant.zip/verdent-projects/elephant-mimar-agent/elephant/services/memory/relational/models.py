from __future__ import annotations
import uuid
from datetime import datetime
from sqlalchemy import (
    BigInteger, Boolean, Column, DateTime, Float,
    ForeignKey, Index, Integer, JSON, String, Text, text
)
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


class Task(Base):
    __tablename__ = "tasks"

    task_id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    created_at = Column(DateTime(timezone=True), nullable=False, server_default=text("now()"))
    updated_at = Column(DateTime(timezone=True), nullable=False, server_default=text("now()"))
    title = Column(String(120), nullable=False)
    task_type = Column(String(64), nullable=False)
    mode = Column(String(16), nullable=False, default="work")
    origin = Column(String(64), nullable=False, default="user")
    brief = Column(JSON, nullable=False, default=dict)
    priority = Column(Integer, nullable=False, default=3)
    status = Column(String(32), nullable=False, default="pending", index=True)
    assigned_agent = Column(String(64), nullable=True, index=True)
    parent_task_id = Column(PGUUID(as_uuid=True), ForeignKey("tasks.task_id"), nullable=True)
    depends_on = Column(JSON, nullable=False, default=list)
    subtask_ids = Column(JSON, nullable=False, default=list)
    deadline = Column(DateTime(timezone=True), nullable=True)
    success_criteria = Column(Text, nullable=False, default="")
    risk_level = Column(String(16), nullable=False, default="low")
    requires_approval = Column(Boolean, nullable=False, default=False)
    approval_status = Column(String(32), nullable=False, default="not_required")
    cost_usd = Column(Float, nullable=False, default=0.0)
    retry_count = Column(Integer, nullable=False, default=0)
    max_retries = Column(Integer, nullable=False, default=3)
    tags = Column(JSON, nullable=False, default=list)
    outputs = Column(JSON, nullable=False, default=list)

    execution_logs = relationship("TaskExecutionLog", back_populates="task", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_tasks_status_priority", "status", "priority"),
        Index("ix_tasks_mode_status", "mode", "status"),
        Index("ix_tasks_created_at", "created_at"),
    )


class TaskExecutionLog(Base):
    __tablename__ = "task_execution_logs"

    log_id = Column(BigInteger, primary_key=True, autoincrement=True)
    task_id = Column(PGUUID(as_uuid=True), ForeignKey("tasks.task_id"), nullable=False, index=True)
    timestamp = Column(DateTime(timezone=True), nullable=False, server_default=text("now()"))
    agent_name = Column(String(64), nullable=False)
    action = Column(String(128), nullable=False)
    result = Column(String(32), nullable=False)
    detail = Column(JSON, nullable=True)
    cost_usd = Column(Float, nullable=False, default=0.0)

    task = relationship("Task", back_populates="execution_logs")

    __table_args__ = (
        Index("ix_task_exec_log_task_agent", "task_id", "agent_name"),
    )


class AgentRegistry(Base):
    __tablename__ = "agent_registry"

    agent_name = Column(String(64), primary_key=True)
    registered_at = Column(DateTime(timezone=True), nullable=False, server_default=text("now()"))
    last_heartbeat = Column(DateTime(timezone=True), nullable=True)
    status = Column(String(32), nullable=False, default="offline")
    current_task_id = Column(PGUUID(as_uuid=True), nullable=True)
    tasks_completed_today = Column(Integer, nullable=False, default=0)
    cost_today_usd = Column(Float, nullable=False, default=0.0)
    enabled = Column(Boolean, nullable=False, default=True)
    config = Column(JSON, nullable=False, default=dict)


class AuditLog(Base):
    __tablename__ = "audit_log"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    event_id = Column(PGUUID(as_uuid=True), nullable=False, default=uuid.uuid4, unique=True)
    timestamp = Column(DateTime(timezone=True), nullable=False, server_default=text("now()"))
    agent_name = Column(String(64), nullable=False)
    action_type = Column(String(64), nullable=False, index=True)
    action_detail = Column(JSON, nullable=False)
    task_id = Column(PGUUID(as_uuid=True), nullable=True, index=True)
    user_triggered = Column(Boolean, nullable=False, default=False)
    cost_usd = Column(Float, nullable=True)
    result_status = Column(String(32), nullable=True)
    prev_hash = Column(String(64), nullable=False, default="genesis")
    row_hash = Column(String(64), nullable=False, default="")

    __table_args__ = (
        Index("ix_audit_log_timestamp", "timestamp"),
        Index("ix_audit_log_agent_action", "agent_name", "action_type"),
    )


class CostRecord(Base):
    __tablename__ = "cost_records"

    record_id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    timestamp = Column(DateTime(timezone=True), nullable=False, server_default=text("now()"), index=True)
    agent_name = Column(String(64), nullable=False, index=True)
    task_id = Column(PGUUID(as_uuid=True), nullable=True)
    model_id = Column(String(128), nullable=False)
    provider = Column(String(64), nullable=False)
    tokens_in = Column(Integer, nullable=False, default=0)
    tokens_out = Column(Integer, nullable=False, default=0)
    cost_usd = Column(Float, nullable=False)

    __table_args__ = (
        Index("ix_cost_records_agent_date", "agent_name", "timestamp"),
    )


class MemoryRecord(Base):
    __tablename__ = "memory_records"

    memory_id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    created_at = Column(DateTime(timezone=True), nullable=False, server_default=text("now()"))
    updated_at = Column(DateTime(timezone=True), nullable=False, server_default=text("now()"))
    memory_type = Column(String(32), nullable=False, index=True)
    source_agent = Column(String(64), nullable=False)
    task_id = Column(PGUUID(as_uuid=True), nullable=True)
    project_id = Column(String(128), nullable=True, index=True)
    content_preview = Column(String(256), nullable=False)
    vector_id = Column(String(128), nullable=True)
    graph_node_id = Column(String(128), nullable=True)
    tags = Column(JSON, nullable=False, default=list)
    ttl_expires_at = Column(DateTime(timezone=True), nullable=True)
    is_personal = Column(Boolean, nullable=False, default=False)

    __table_args__ = (
        Index("ix_memory_type_project", "memory_type", "project_id"),
        Index("ix_memory_personal", "is_personal"),
    )


class SystemEvent(Base):
    __tablename__ = "system_events"

    event_id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    timestamp = Column(DateTime(timezone=True), nullable=False, server_default=text("now()"), index=True)
    event_type = Column(String(64), nullable=False, index=True)
    severity = Column(String(16), nullable=False, default="info")
    source = Column(String(64), nullable=False)
    message = Column(Text, nullable=False)
    detail = Column(JSON, nullable=True)
    acknowledged = Column(Boolean, nullable=False, default=False)
    acknowledged_at = Column(DateTime(timezone=True), nullable=True)
