from shared.schemas.task import TaskType

TASK_TYPE_TO_AGENT: dict[str, str] = {
    TaskType.research.value: "researcher",
    TaskType.content_creation.value: "creator",
    TaskType.image_generation.value: "visual",
    TaskType.strategy.value: "creator",
    TaskType.report.value: "reporter",
    TaskType.publish.value: "executor",
    TaskType.reminder.value: "interacter",
    TaskType.personal.value: "interacter",
    TaskType.system.value: "watchdog",
}


def route_task(task_type: str) -> str:
    return TASK_TYPE_TO_AGENT.get(task_type, "planner")
