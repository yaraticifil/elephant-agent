from __future__ import annotations
import logging
from uuid import UUID
from shared.schemas.task import TaskCreate, TaskRead, TaskStatus, TaskUpdate
from shared.messaging.bus import MessageBus
from shared.messaging.events import build_task_event, build_alert_event
from shared.schemas.message import EventType

logger = logging.getLogger(__name__)


class TaskEngine:
    def __init__(self, task_repo, bus: MessageBus):
        self.repo = task_repo
        self.bus = bus

    async def create_task(self, data: TaskCreate) -> TaskRead:
        task = await self.repo.create(data)
        logger.info("task_created", extra={"task_id": str(task.task_id), "type": task.task_type})
        await self.bus.publish(build_task_event(EventType.task_created, task, "orchestrator"))
        return task

    async def assign_task(self, task_id: UUID, agent_name: str) -> TaskRead | None:
        task = await self.repo.update(task_id, TaskUpdate(
            status=TaskStatus.active, assigned_agent=agent_name
        ))
        if task:
            await self.bus.publish(build_task_event(
                EventType.task_assigned, task, "orchestrator", recipient=agent_name
            ))
            logger.info("task_assigned", extra={"task_id": str(task_id), "agent": agent_name})
        return task

    async def complete_task(self, task_id: UUID, outputs: list[str], cost_usd: float = 0.0) -> TaskRead | None:
        task = await self.repo.update(task_id, TaskUpdate(
            status=TaskStatus.completed, outputs=outputs, cost_usd=cost_usd
        ))
        if task:
            await self.bus.publish(build_task_event(EventType.task_completed, task, "orchestrator"))
            logger.info("task_completed", extra={"task_id": str(task_id), "cost": cost_usd})
        return task

    async def fail_task(self, task_id: UUID, error: str) -> TaskRead | None:
        task = await self.repo.get(task_id)
        if not task:
            return None
        if task.retry_count < task.max_retries:
            await self.repo.increment_retry(task_id)
            updated = await self.repo.update(task_id, TaskUpdate(status=TaskStatus.queued))
            logger.warning("task_retry", extra={"task_id": str(task_id), "retry": task.retry_count + 1})
            return updated
        else:
            updated = await self.repo.update(task_id, TaskUpdate(status=TaskStatus.escalated))
            if updated:
                await self.bus.publish(build_task_event(
                    EventType.task_escalated, updated, "orchestrator",
                    payload={"error": error, "reason": "max_retries_exceeded"}
                ))
                await self.bus.publish(build_alert_event(
                    "orchestrator",
                    f"Task escalated after max retries: {task.title}",
                    "warning",
                    {"task_id": str(task_id), "error": error}
                ))
            logger.error("task_escalated", extra={"task_id": str(task_id)})
            return updated

    async def cancel_task(self, task_id: UUID, reason: str) -> TaskRead | None:
        task = await self.repo.update(task_id, TaskUpdate(status=TaskStatus.cancelled))
        if task:
            await self.bus.publish(build_task_event(
                EventType.task_cancelled, task, "orchestrator",
                payload={"reason": reason}
            ))
            logger.info("task_cancelled", extra={"task_id": str(task_id), "reason": reason})
        return task
