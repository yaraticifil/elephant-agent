from __future__ import annotations
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from shared.logging.config import configure_logging
from shared.config.base import get_settings
from shared.messaging.bus import MessageBus
from services.orchestrator.db.session import engine
from services.memory.relational.models import Base
from services.orchestrator.api.routes import health, tasks, agents

settings = get_settings()
configure_logging("orchestrator", settings.LOG_LEVEL)
logger = logging.getLogger(__name__)

bus_instance: MessageBus = MessageBus(settings.REDIS_URL)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("orchestrator_starting")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    await bus_instance.connect()
    logger.info("orchestrator_ready")
    yield
    await bus_instance.disconnect()
    await engine.dispose()
    logger.info("orchestrator_stopped")


app = FastAPI(
    title="ELEPHANT Orchestrator",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(tasks.router)
app.include_router(agents.router)
