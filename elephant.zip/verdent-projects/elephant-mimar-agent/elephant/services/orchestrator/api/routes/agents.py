from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from services.orchestrator.db.session import get_session
from services.memory.relational.models import AgentRegistry
from shared.schemas.agent import AgentStatusRead, AgentHealthStatus

router = APIRouter(prefix="/agents", tags=["agents"])


@router.get("", response_model=list[AgentStatusRead])
async def list_agents(session: AsyncSession = Depends(get_session)):
    result = await session.execute(select(AgentRegistry))
    agents = result.scalars().all()
    return [
        AgentStatusRead(
            agent_name=a.agent_name,
            status=AgentHealthStatus(a.status),
            last_heartbeat=a.last_heartbeat,
            current_task_id=a.current_task_id,
            tasks_completed_today=a.tasks_completed_today,
            cost_today_usd=a.cost_today_usd,
            uptime_seconds=None,
            enabled=a.enabled,
        )
        for a in agents
    ]


@router.get("/{agent_name}", response_model=AgentStatusRead)
async def get_agent(agent_name: str, session: AsyncSession = Depends(get_session)):
    agent = await session.get(AgentRegistry, agent_name)
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent {agent_name} not found")
    return AgentStatusRead(
        agent_name=agent.agent_name,
        status=AgentHealthStatus(agent.status),
        last_heartbeat=agent.last_heartbeat,
        current_task_id=agent.current_task_id,
        tasks_completed_today=agent.tasks_completed_today,
        cost_today_usd=agent.cost_today_usd,
        uptime_seconds=None,
        enabled=agent.enabled,
    )
