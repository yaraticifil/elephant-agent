from __future__ import annotations
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from services.orchestrator.db.session import get_session
from services.orchestrator.db.repositories.task_repo import TaskRepository
from services.orchestrator.core.task_engine import TaskEngine
from shared.schemas.task import TaskCreate, TaskRead
from shared.messaging.bus import MessageBus

router = APIRouter(prefix="/tasks", tags=["tasks"])


def get_bus() -> MessageBus:
    from services.orchestrator.main import bus_instance
    return bus_instance


@router.post("", response_model=TaskRead, status_code=201)
async def create_task(
    data: TaskCreate,
    session: AsyncSession = Depends(get_session),
    bus: MessageBus = Depends(get_bus),
):
    repo = TaskRepository(session)
    engine = TaskEngine(repo, bus)
    return await engine.create_task(data)


@router.get("", response_model=list[TaskRead])
async def list_tasks(
    status: str | None = Query(None),
    task_type: str | None = Query(None),
    mode: str | None = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    session: AsyncSession = Depends(get_session),
):
    repo = TaskRepository(session)
    return await repo.list(status=status, task_type=task_type, mode=mode, limit=limit, offset=offset)


@router.get("/{task_id}", response_model=TaskRead)
async def get_task(task_id: UUID, session: AsyncSession = Depends(get_session)):
    repo = TaskRepository(session)
    task = await repo.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    return task


@router.post("/{task_id}/complete", response_model=TaskRead)
async def complete_task(
    task_id: UUID,
    outputs: list[str] = [],
    cost_usd: float = 0.0,
    session: AsyncSession = Depends(get_session),
    bus: MessageBus = Depends(get_bus),
):
    repo = TaskRepository(session)
    engine = TaskEngine(repo, bus)
    task = await engine.complete_task(task_id, outputs, cost_usd)
    if not task:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    return task


@router.post("/{task_id}/fail", response_model=TaskRead)
async def fail_task(
    task_id: UUID,
    error: str = "Unknown error",
    session: AsyncSession = Depends(get_session),
    bus: MessageBus = Depends(get_bus),
):
    repo = TaskRepository(session)
    engine = TaskEngine(repo, bus)
    task = await engine.fail_task(task_id, error)
    if not task:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    return task


@router.delete("/{task_id}", response_model=TaskRead)
async def cancel_task(
    task_id: UUID,
    reason: str = "User cancelled",
    session: AsyncSession = Depends(get_session),
    bus: MessageBus = Depends(get_bus),
):
    repo = TaskRepository(session)
    engine = TaskEngine(repo, bus)
    task = await engine.cancel_task(task_id, reason)
    if not task:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    return task
