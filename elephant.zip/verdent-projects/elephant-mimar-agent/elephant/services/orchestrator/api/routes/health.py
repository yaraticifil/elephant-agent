from __future__ import annotations
from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
async def health():
    return {
        "service": "orchestrator",
        "status": "ok",
        "version": "0.1.0",
    }
