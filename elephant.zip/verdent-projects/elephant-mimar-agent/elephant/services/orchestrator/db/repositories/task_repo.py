from __future__ import annotations
from datetime import datetime, timezone
from uuid import UUID
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from services.memory.relational.models import Task
from shared.schemas.task import TaskCreate, TaskRead, TaskUpdate, TaskStatus, TaskBrief


def _to_read(task: Task) -> TaskRead:
    return TaskRead(
        task_id=task.task_id,
        created_at=task.created_at,
        updated_at=task.updated_at,
        title=task.title,
        task_type=task.task_type,
        mode=task.mode,
        origin=task.origin,
        brief=TaskBrief(**task.brief) if isinstance(task.brief, dict) else task.brief,
        priority=task.priority,
        status=task.status,
        assigned_agent=task.assigned_agent,
        parent_task_id=task.parent_task_id,
        subtask_ids=task.subtask_ids or [],
        depends_on=task.depends_on or [],
        deadline=task.deadline,
        success_criteria=task.success_criteria,
        risk_level=task.risk_level,
        requires_approval=task.requires_approval,
        approval_status=task.approval_status,
        cost_usd=task.cost_usd,
        retry_count=task.retry_count,
        max_retries=task.max_retries,
        tags=task.tags or [],
        outputs=task.outputs or [],
    )


class TaskRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, data: TaskCreate) -> TaskRead:
        task = Task(
            title=data.title,
            task_type=data.task_type.value,
            mode=data.mode.value,
            origin=data.origin.value,
            brief=data.brief.model_dump(),
            priority=data.priority.value,
            status=TaskStatus.pending.value,
            parent_task_id=data.parent_task_id,
            depends_on=[str(d) for d in data.depends_on],
            subtask_ids=[],
            deadline=data.deadline,
            success_criteria=data.success_criteria,
            risk_level=data.risk_level.value,
            requires_approval=data.risk_level.value == "high",
            approval_status="not_required",
            tags=data.tags,
            outputs=[],
        )
        self.session.add(task)
        await self.session.flush()
        await self.session.refresh(task)
        return _to_read(task)

    async def get(self, task_id: UUID) -> TaskRead | None:
        result = await self.session.execute(select(Task).where(Task.task_id == task_id))
        task = result.scalar_one_or_none()
        return _to_read(task) if task else None

    async def list(
        self,
        status: str | None = None,
        task_type: str | None = None,
        mode: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[TaskRead]:
        q = select(Task)
        if status:
            q = q.where(Task.status == status)
        if task_type:
            q = q.where(Task.task_type == task_type)
        if mode:
            q = q.where(Task.mode == mode)
        q = q.order_by(Task.priority, Task.created_at).limit(limit).offset(offset)
        result = await self.session.execute(q)
        return [_to_read(t) for t in result.scalars().all()]

    async def update(self, task_id: UUID, data: TaskUpdate) -> TaskRead | None:
        values: dict = {"updated_at": datetime.now(timezone.utc)}
        if data.status is not None:
            values["status"] = data.status.value
        if data.assigned_agent is not None:
            values["assigned_agent"] = data.assigned_agent
        if data.priority is not None:
            values["priority"] = data.priority
        if data.cost_usd is not None:
            values["cost_usd"] = data.cost_usd
        if data.outputs is not None:
            values["outputs"] = data.outputs
        if data.approval_status is not None:
            values["approval_status"] = data.approval_status

        await self.session.execute(
            update(Task).where(Task.task_id == task_id).values(**values)
        )
        await self.session.flush()
        return await self.get(task_id)

    async def increment_retry(self, task_id: UUID) -> None:
        task = await self.session.get(Task, task_id)
        if task:
            task.retry_count += 1
            task.updated_at = datetime.now(timezone.utc)
            await self.session.flush()
