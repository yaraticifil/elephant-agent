from __future__ import annotations


class ModelRouter:
    """
    Stage 1: stub router — returns local model for everything.
    Stage 5: real routing logic based on privacy, complexity, cost.
    """

    def route(self, task_type: str, privacy: str = "internal", complexity: float = 0.5) -> dict:
        if privacy in ("personal", "confidential"):
            return {"model": "llama3.1:8b", "provider": "local", "reason": "privacy_override"}
        return {"model": "llama3.1:8b", "provider": "local", "reason": "stage1_stub"}


router = ModelRouter()
