FROM python:3.11-slim

WORKDIR /app

RUN apt-get update && apt-get install -y curl && rm -rf /var/lib/apt/lists/*

RUN pip install --no-cache-dir \
    fastapi==0.111.0 \
    uvicorn[standard]==0.29.0 \
    sqlalchemy[asyncio]==2.0.30 \
    asyncpg==0.29.0 \
    alembic==1.13.1 \
    redis==5.0.4 \
    pydantic==2.7.1 \
    pydantic-settings==2.2.1 \
    httpx==0.27.0 \
    celery[redis]==5.4.0

COPY shared/ ./shared/
COPY config/ ./config/
COPY services/ ./services/

ENV PYTHONPATH=/app
ENV PYTHONUNBUFFERED=1
